/****************************************************************************
** Meta object code from reading C++ file 'settwindget.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.1.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../untitled/settwindget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'settwindget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.1.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_SettWindget_t {
    const uint offsetsAndSize[34];
    char stringdata0[263];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_SettWindget_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_SettWindget_t qt_meta_stringdata_SettWindget = {
    {
QT_MOC_LITERAL(0, 11), // "SettWindget"
QT_MOC_LITERAL(12, 12), // "SendDataBack"
QT_MOC_LITERAL(25, 0), // ""
QT_MOC_LITERAL(26, 20), // "QList<QKeySequence>&"
QT_MOC_LITERAL(47, 8), // "KeyBinds"
QT_MOC_LITERAL(56, 21), // "Qt::KeyboardModifier&"
QT_MOC_LITERAL(78, 12), // "ModifierBind"
QT_MOC_LITERAL(91, 10), // "ReciveData"
QT_MOC_LITERAL(102, 4), // "Lang"
QT_MOC_LITERAL(107, 20), // "on_OpenApply_clicked"
QT_MOC_LITERAL(128, 19), // "on_ApplyMod_clicked"
QT_MOC_LITERAL(148, 13), // "onButtonApply"
QT_MOC_LITERAL(162, 20), // "on_AppChange_clicked"
QT_MOC_LITERAL(183, 20), // "on_SaveApply_clicked"
QT_MOC_LITERAL(204, 21), // "on_CloseApply_clicked"
QT_MOC_LITERAL(226, 19), // "on_NewApply_clicked"
QT_MOC_LITERAL(246, 16) // "on_Reset_clicked"

    },
    "SettWindget\0SendDataBack\0\0"
    "QList<QKeySequence>&\0KeyBinds\0"
    "Qt::KeyboardModifier&\0ModifierBind\0"
    "ReciveData\0Lang\0on_OpenApply_clicked\0"
    "on_ApplyMod_clicked\0onButtonApply\0"
    "on_AppChange_clicked\0on_SaveApply_clicked\0"
    "on_CloseApply_clicked\0on_NewApply_clicked\0"
    "on_Reset_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_SettWindget[] = {

 // content:
       9,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    2,   74,    2, 0x06,    0 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       7,    3,   79,    2, 0x0a,    3 /* Public */,
       9,    0,   86,    2, 0x08,    7 /* Private */,
      10,    0,   87,    2, 0x08,    8 /* Private */,
      11,    0,   88,    2, 0x08,    9 /* Private */,
      12,    0,   89,    2, 0x08,   10 /* Private */,
      13,    0,   90,    2, 0x08,   11 /* Private */,
      14,    0,   91,    2, 0x08,   12 /* Private */,
      15,    0,   92,    2, 0x08,   13 /* Private */,
      16,    0,   93,    2, 0x08,   14 /* Private */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 5,    4,    6,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 5, QMetaType::Int,    4,    6,    8,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void SettWindget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<SettWindget *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->SendDataBack((*reinterpret_cast< QList<QKeySequence>(*)>(_a[1])),(*reinterpret_cast< Qt::KeyboardModifier(*)>(_a[2]))); break;
        case 1: _t->ReciveData((*reinterpret_cast< QList<QKeySequence>(*)>(_a[1])),(*reinterpret_cast< Qt::KeyboardModifier(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 2: _t->on_OpenApply_clicked(); break;
        case 3: _t->on_ApplyMod_clicked(); break;
        case 4: _t->onButtonApply(); break;
        case 5: _t->on_AppChange_clicked(); break;
        case 6: _t->on_SaveApply_clicked(); break;
        case 7: _t->on_CloseApply_clicked(); break;
        case 8: _t->on_NewApply_clicked(); break;
        case 9: _t->on_Reset_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (SettWindget::*)(QList<QKeySequence> & , Qt::KeyboardModifier & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SettWindget::SendDataBack)) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject SettWindget::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_SettWindget.offsetsAndSize,
    qt_meta_data_SettWindget,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_SettWindget_t
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QList<QKeySequence> &, std::false_type>, QtPrivate::TypeAndForceComplete<Qt::KeyboardModifier &, std::false_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QList<QKeySequence> &, std::false_type>, QtPrivate::TypeAndForceComplete<Qt::KeyboardModifier &, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>


>,
    nullptr
} };


const QMetaObject *SettWindget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SettWindget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_SettWindget.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int SettWindget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 10)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 10;
    }
    return _id;
}

// SIGNAL 0
void SettWindget::SendDataBack(QList<QKeySequence> & _t1, Qt::KeyboardModifier & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
