/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.1.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../untitled/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.1.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    const uint offsetsAndSize[62];
    char stringdata0[304];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 10), // "MainWindow"
QT_MOC_LITERAL(11, 8), // "SendData"
QT_MOC_LITERAL(20, 0), // ""
QT_MOC_LITERAL(21, 20), // "QList<QKeySequence>&"
QT_MOC_LITERAL(42, 8), // "KeyBinds"
QT_MOC_LITERAL(51, 21), // "Qt::KeyboardModifier&"
QT_MOC_LITERAL(73, 12), // "ModifierBind"
QT_MOC_LITERAL(86, 4), // "lang"
QT_MOC_LITERAL(91, 8), // "SendLang"
QT_MOC_LITERAL(100, 10), // "SendFolder"
QT_MOC_LITERAL(111, 8), // "QString&"
QT_MOC_LITERAL(120, 6), // "folder"
QT_MOC_LITERAL(127, 15), // "keyReleaseEvent"
QT_MOC_LITERAL(143, 10), // "QKeyEvent*"
QT_MOC_LITERAL(154, 5), // "event"
QT_MOC_LITERAL(160, 12), // "onButtonSend"
QT_MOC_LITERAL(173, 3), // "New"
QT_MOC_LITERAL(177, 4), // "Open"
QT_MOC_LITERAL(182, 6), // "ROOpen"
QT_MOC_LITERAL(189, 4), // "Exit"
QT_MOC_LITERAL(194, 4), // "Save"
QT_MOC_LITERAL(199, 5), // "About"
QT_MOC_LITERAL(205, 10), // "FolderOpen"
QT_MOC_LITERAL(216, 10), // "ChangeDark"
QT_MOC_LITERAL(227, 11), // "ChangeLight"
QT_MOC_LITERAL(239, 8), // "RuTransl"
QT_MOC_LITERAL(248, 8), // "EnTransl"
QT_MOC_LITERAL(257, 11), // "PrintDialog"
QT_MOC_LITERAL(269, 10), // "ReciveBack"
QT_MOC_LITERAL(280, 9), // "RKeyBinds"
QT_MOC_LITERAL(290, 13) // "RModifierBind"

    },
    "MainWindow\0SendData\0\0QList<QKeySequence>&\0"
    "KeyBinds\0Qt::KeyboardModifier&\0"
    "ModifierBind\0lang\0SendLang\0SendFolder\0"
    "QString&\0folder\0keyReleaseEvent\0"
    "QKeyEvent*\0event\0onButtonSend\0New\0"
    "Open\0ROOpen\0Exit\0Save\0About\0FolderOpen\0"
    "ChangeDark\0ChangeLight\0RuTransl\0"
    "EnTransl\0PrintDialog\0ReciveBack\0"
    "RKeyBinds\0RModifierBind"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       9,       // revision
       0,       // classname
       0,    0, // classinfo
      18,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    3,  122,    2, 0x06,    0 /* Public */,
       8,    1,  129,    2, 0x06,    4 /* Public */,
       9,    1,  132,    2, 0x06,    6 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      12,    1,  135,    2, 0x08,    8 /* Private */,
      15,    0,  138,    2, 0x08,   10 /* Private */,
      16,    0,  139,    2, 0x08,   11 /* Private */,
      17,    0,  140,    2, 0x08,   12 /* Private */,
      18,    0,  141,    2, 0x08,   13 /* Private */,
      19,    0,  142,    2, 0x08,   14 /* Private */,
      20,    0,  143,    2, 0x08,   15 /* Private */,
      21,    0,  144,    2, 0x08,   16 /* Private */,
      22,    0,  145,    2, 0x08,   17 /* Private */,
      23,    0,  146,    2, 0x08,   18 /* Private */,
      24,    0,  147,    2, 0x08,   19 /* Private */,
      25,    0,  148,    2, 0x08,   20 /* Private */,
      26,    0,  149,    2, 0x08,   21 /* Private */,
      27,    0,  150,    2, 0x08,   22 /* Private */,
      28,    2,  151,    2, 0x0a,   23 /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 5, QMetaType::Int,    4,    6,    7,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void, 0x80000000 | 10,   11,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 13,   14,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 5,   29,   30,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->SendData((*reinterpret_cast< QList<QKeySequence>(*)>(_a[1])),(*reinterpret_cast< Qt::KeyboardModifier(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 1: _t->SendLang((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->SendFolder((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->keyReleaseEvent((*reinterpret_cast< QKeyEvent*(*)>(_a[1]))); break;
        case 4: _t->onButtonSend(); break;
        case 5: _t->New(); break;
        case 6: _t->Open(); break;
        case 7: _t->ROOpen(); break;
        case 8: _t->Exit(); break;
        case 9: _t->Save(); break;
        case 10: _t->About(); break;
        case 11: _t->FolderOpen(); break;
        case 12: _t->ChangeDark(); break;
        case 13: _t->ChangeLight(); break;
        case 14: _t->RuTransl(); break;
        case 15: _t->EnTransl(); break;
        case 16: _t->PrintDialog(); break;
        case 17: _t->ReciveBack((*reinterpret_cast< QList<QKeySequence>(*)>(_a[1])),(*reinterpret_cast< Qt::KeyboardModifier(*)>(_a[2]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (MainWindow::*)(QList<QKeySequence> & , Qt::KeyboardModifier & , int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::SendData)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::SendLang)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::SendFolder)) {
                *result = 2;
                return;
            }
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.offsetsAndSize,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_MainWindow_t
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QList<QKeySequence> &, std::false_type>, QtPrivate::TypeAndForceComplete<Qt::KeyboardModifier &, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString &, std::false_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QKeyEvent *, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QList<QKeySequence> &, std::false_type>, QtPrivate::TypeAndForceComplete<Qt::KeyboardModifier &, std::false_type>


>,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 18)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 18;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::SendData(QList<QKeySequence> & _t1, Qt::KeyboardModifier & _t2, int _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void MainWindow::SendLang(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void MainWindow::SendFolder(QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
